Official info about translation: http://codex.wordpress.org/Translating_WordPress



Open lavan-en_US.po file and save new copy as lavan-es.po for Spanish.And then use translating program to translate it to Spanish language.